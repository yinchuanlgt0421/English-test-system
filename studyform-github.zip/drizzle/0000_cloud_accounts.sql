CREATE TABLE sf_accounts (id TEXT PRIMARY KEY NOT NULL, email TEXT NOT NULL, name TEXT NOT NULL, provider TEXT NOT NULL, password_hash TEXT, salt TEXT, created_at INTEGER NOT NULL);
--> statement-breakpoint
CREATE UNIQUE INDEX sf_account_identity ON sf_accounts(email,provider);
--> statement-breakpoint
CREATE TABLE sf_sessions (token_hash TEXT PRIMARY KEY NOT NULL, account_id TEXT NOT NULL, expires_at INTEGER NOT NULL);
--> statement-breakpoint
CREATE TABLE sf_states (owner TEXT PRIMARY KEY NOT NULL, data TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL);
--> statement-breakpoint
CREATE TABLE sf_files (id TEXT PRIMARY KEY NOT NULL, owner TEXT NOT NULL, object_key TEXT NOT NULL, name TEXT NOT NULL, mime TEXT NOT NULL, size INTEGER NOT NULL, created_at INTEGER NOT NULL);
--> statement-breakpoint
CREATE TABLE sf_rate_limits (bucket TEXT PRIMARY KEY NOT NULL, count INTEGER NOT NULL, expires_at INTEGER NOT NULL);
