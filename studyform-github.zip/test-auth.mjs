import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import vm from 'node:vm';
import worker from './worker/index.mjs';
const sql=new DatabaseSync(':memory:');sql.exec(fs.readFileSync('drizzle/0000_cloud_accounts.sql','utf8'));
const DB={prepare(statement){return {bind(...values){return {
  async first(){return sql.prepare(statement).get(...values)||null},
  async run(){return {meta:{changes:Number(sql.prepare(statement).run(...values).changes)}}}
}}}}};
const env={DB,GOOGLE_CLIENT_ID:'123456789-client-test.apps.googleusercontent.com'};
async function call(path,body,{origin='https://studyform.test',cookies='',method='POST'}={}){
  return worker.fetch(new Request(origin+path,{method,headers:{origin,cookie:cookies,'content-type':'application/json'},body:method==='GET'?undefined:JSON.stringify(body||{})}),env);
}
let res=await call('/api/auth/register',{email:'auth@example.com',password:'valid-password-123',name:'測試'});assert.equal(res.status,200);
assert(res.headers.get('set-cookie').includes('__Host-sf_session='));assert(res.headers.get('set-cookie').includes('Secure;'));assert(res.headers.get('set-cookie').includes('SameSite=Lax'));
res=await call('/api/auth/register',{email:'auth@example.com',password:'valid-password-123'});assert.equal(res.status,409);
res=await call('/api/auth/login',{email:'auth@example.com',password:'valid-password-123'},{origin:'http://127.0.0.1:4180'});assert.equal(res.status,200);
const localCookie=res.headers.get('set-cookie').split(';')[0];assert(localCookie.startsWith('sf_session_local='));assert(!res.headers.get('set-cookie').includes('Secure;'));
res=await call('/api/me',null,{origin:'http://127.0.0.1:4180',cookies:localCookie,method:'GET'});assert.equal((await res.json()).user.email,'auth@example.com');
res=await call('/api/me',null,{cookies:localCookie,method:'GET'});assert.equal((await res.json()).user,null);
const keys=await crypto.subtle.generateKey({name:'RSASSA-PKCS1-v1_5',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['sign','verify']);
const jwk=await crypto.subtle.exportKey('jwk',keys.publicKey);jwk.kid='test-key';jwk.alg='RS256';jwk.use='sig';
const realFetch=globalThis.fetch;globalThis.fetch=async url=>{assert.equal(String(url),'https://www.googleapis.com/oauth2/v3/certs');return new Response(JSON.stringify({keys:[jwk]}),{headers:{'content-type':'application/json','cache-control':'max-age=3600'}})};
const b64=s=>Buffer.from(s).toString('base64url');
async function token(nonce,changes={}){const now=Math.floor(Date.now()/1000),header=b64(JSON.stringify({alg:'RS256',kid:'test-key'})),payload=b64(JSON.stringify({sub:'google-test-sub',email:'google-test@example.com',name:'測試Google',email_verified:true,aud:env.GOOGLE_CLIENT_ID,iss:'https://accounts.google.com',iat:now,exp:now+600,nonce,...changes}));const signature=await crypto.subtle.sign('RSASSA-PKCS1-v1_5',keys.privateKey,new TextEncoder().encode(header+'.'+payload));return header+'.'+payload+'.'+b64(signature)}
res=await call('/api/google/nonce',{});assert.equal(res.status,200);const nonceCookie=res.headers.get('set-cookie').split(';')[0],{nonce}=await res.json();
res=await call('/api/auth/google',{credential:await token(nonce)},{cookies:nonceCookie});assert.equal(res.status,200);const googleCookie=res.headers.getSetCookie().find(c=>c.startsWith('__Host-sf_session=')).split(';')[0];
res=await call('/api/me',null,{cookies:googleCookie,method:'GET'});const googleUser=(await res.json()).user;assert.equal(googleUser.provider,'google');assert.equal(googleUser.id,'google:google-test-sub');
res=await call('/api/auth/google',{credential:await token(nonce,{aud:'wrong-app'})},{cookies:nonceCookie});assert.equal(res.status,401);
res=await call('/api/auth/google',{credential:await token(nonce,{exp:1})},{cookies:nonceCookie});assert.equal(res.status,401);
res=await call('/api/auth/google',{credential:await token(nonce,{exp:undefined})},{cookies:nonceCookie});assert.equal(res.status,401);
res=await call('/api/auth/google',{credential:await token('wrong-nonce')},{cookies:nonceCookie});assert.equal(res.status,401);
globalThis.fetch=realFetch;
const root={innerHTML:''},fields={},modal={addEventListener(){}};
const context={document:{querySelector:s=>s==='#app'?root:s==='#modal'?modal:fields[s]||(fields[s]={}),querySelectorAll:()=>[]},window:{addEventListener(){},scrollTo(){}},location:{protocol:'https:',pathname:'/',origin:'https://example.github.io'},fetch:async()=>new Response('<html>404</html>',{status:404}),AbortSignal,crypto,structuredClone,FormData,Response,setTimeout,clearTimeout};
vm.createContext(context);vm.runInContext(fs.readFileSync('web/app.js','utf8'),context);await new Promise(r=>setTimeout(r,30));assert(root.innerHTML.includes('目前尚未連接登入後台'));assert(!root.innerHTML.includes('id="register-form"'));assert(!root.innerHTML.includes('id="login-form"'));
console.log('PASS: local HTTP cookies, production secure cookies, duplicate registration, signed Google login, nonce/audience/expiry checks, static preview blocks unusable login forms.');
sql.close();
