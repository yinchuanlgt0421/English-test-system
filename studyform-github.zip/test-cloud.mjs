import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import worker,{validateAI} from './worker/index.mjs';
const sqlite=new DatabaseSync(':memory:');sqlite.exec(readFileSync('drizzle/0000_cloud_accounts.sql','utf8'));
const DB={
  prepare(sql){
    return {bind(...values){
      return {
        async first(){return sqlite.prepare(sql).get(...values)||null},
        async run(){const r=sqlite.prepare(sql).run(...values);return {meta:{changes:Number(r.changes)}}}
      };
    }};
  }
};
const objects=new Map(),BUCKET={async put(k,stream){objects.set(k,new Uint8Array(await new Response(stream).arrayBuffer()))},async get(k){return objects.has(k)?{body:objects.get(k)}:null},async delete(k){objects.delete(k)}};
const env={DB,BUCKET},origin='https://studyform.test';
async function call(path,method='GET',body,options={}){const r=new Request(origin+path,{method,headers:{origin,...(body&&!(body instanceof FormData)?{'content-type':'application/json'}:{}),...options.headers},body:body instanceof FormData?body:body?JSON.stringify(body):undefined});return worker.fetch(r,env)}
let res=await call('/api/state');assert.equal(res.status,401);
res=await call('/api/auth/register','POST',{email:'student-a@example.com',password:'A-test-password-123',name:'學生A'});assert.equal(res.status,200);const cookieA=res.headers.get('set-cookie').split(';')[0];assert(cookieA.includes('__Host-sf_session='));assert(res.headers.get('set-cookie').includes('HttpOnly'));
res=await call('/api/auth/login','POST',{email:'student-a@example.com',password:'A-test-password-123'});assert.equal(res.status,200);
res=await call('/api/auth/login','POST',{email:'student-a@example.com',password:'incorrect-pass'});assert.equal(res.status,401);
res=await call('/api/auth/register','POST',{email:'student-b@example.com',password:'B-test-password-123',name:'學生B'});assert.equal(res.status,200);const cookieB=res.headers.get('set-cookie').split(';')[0];
const a={headers:{cookie:cookieA}},platform={headers:{cookie:cookieB}};
res=await call('/api/me','GET',null,{headers:{'oai-authenticated-user-id':'forged-user'}});assert.equal((await res.json()).user,null);
res=await call('/api/state','GET',null,a);let data=await res.json();assert.deepEqual(data.state,{folders:[],templates:[],exams:[]});assert.equal(data.revision,0);
const state={folders:[{id:'folder-a',name:'第3課',cards:[{id:'card-a',word:'achieve',meaning:'達成'}]}],templates:[],exams:[]};
res=await call('/api/state','PUT',{state,revision:0},a);assert.equal(res.status,200);assert.equal((await res.json()).revision,1);
res=await call('/api/state','PUT',{state,revision:0},a);assert.equal(res.status,409);
res=await call('/api/state','GET',null,platform);assert.equal((await res.json()).state.folders.length,0);
res=await call('/api/state','GET',null,a);assert.equal((await res.json()).state.folders[0].name,'第3課');
const form=new FormData();form.append('file',new Blob(['lesson words'],{type:'text/plain'}),'lesson.txt');res=await call('/api/files','POST',form,a);assert.equal(res.status,200);const file=await res.json();assert.equal(objects.size,1);
res=await call('/api/files/'+file.id,'GET',null,a);assert.equal(res.status,200);assert.equal(await res.text(),'lesson words');
res=await call('/api/files/'+file.id,'GET',null,platform);assert.equal(res.status,404);
res=await call('/api/state','PUT',{state,revision:1},{headers:{...a.headers,origin:'https://evil.test'}});assert.equal(res.status,403);
res=await call('/api/auth/google','POST',{credential:'invalid'},a);assert.equal(res.status,503);
res=await call('/api/models','POST',null,a);assert.equal(res.status,400);
assert.throws(()=>validateAI('exam',{questions:[{sectionIndex:0,type:'choice',prompt:'?',answer:'achieve',options:['achieve','test'],explanation:'理由',sourceIds:['unregistered'],targetWords:['achieve']}]},{cards:[{id:'card-a',word:'achieve'}],template:{sections:[{type:'choice',count:1}]}}),/範圍/);
assert.throws(()=>validateAI('exam',{questions:[]},{cards:[],template:{sections:[{type:'rewrite',count:2}]}}),/題數/);
const realFetch=globalThis.fetch;let upstream;
globalThis.fetch=async (url,options)=>{upstream={url,options};return new Response(JSON.stringify({candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify({summary:'辨識完成',warnings:[],cards:[{word:'achieve',meaning:'達成',example:'',kind:'vocabulary',sourceIndex:0,uncertain:false}]})}]}}]}),{headers:{'content-type':'application/json'}})};
res=await call('/api/ai','POST',{task:'materials',model:'gemini-3.8-flash',files:[{name:'words.txt',mime:'text/plain',data:btoa('achieve')}]},{headers:{...a.headers,'x-gemini-api-key':'fake-key-for-contract-test'}});assert.equal(res.status,200);assert.equal((await res.json()).data.cards[0].word,'achieve');assert.equal(upstream.options.headers['x-goog-api-key'],'fake-key-for-contract-test');assert(upstream.url.startsWith('https://generativelanguage.googleapis.com/'));assert.equal(sqlite.prepare('SELECT COUNT(*) AS count FROM sf_states WHERE data LIKE ?').get('%fake-key%').count,0);globalThis.fetch=realFetch;
res=await call('/api/auth/logout','POST',null,a);assert.equal(res.status,200);res=await call('/api/state','GET',null,a);assert.equal(res.status,401);
const appRoot={innerHTML:'載入中'},modal={addEventListener(){}};
const fields={},document={querySelector:s=>s==='#app'?appRoot:s==='#modal'?modal:fields[s]||(fields[s]={}),querySelectorAll:()=>[]};
const fakeFetch=async url=>new Response(JSON.stringify(url==='/api/me'?{user:{id:'site:demo',name:'測試同學',provider:'site'},googleClientId:''}:{state:{folders:[],templates:[],exams:[]},revision:0}),{headers:{'content-type':'application/json'}});
const context={document,window:{addEventListener(){},scrollTo(){}},location:{origin},fetch:fakeFetch,AbortSignal,structuredClone,crypto,FormData,Response,console,setTimeout,clearTimeout};
Object.defineProperty(context,'top',{value:{},configurable:false});
vm.createContext(context);vm.runInContext(readFileSync('web/app.js','utf8'),context);await new Promise(resolve=>setTimeout(resolve,40));
assert(appRoot.innerHTML.includes('從你的第一個範圍開始'));assert(!appRoot.innerHTML.includes('Dream Big'));assert(appRoot.innerHTML.includes('Gemini AI 工作台'));
console.log('PASS: signup/login, password verification, secure session/logout, empty first account, cross-user state and file isolation, revision conflict, CSRF, Google config gate, Gemini contract, no API key persistence, AI scope guards, empty-state startup');
sqlite.close();
