# 範圍內 Studyform

## 1.2 出卷修正

60 題選擇卷改為每批 10 題，介面顯示完成進度。同一分頁若中途失敗，可維持原範圍、樣式與名稱接續重試，已完成批次不重生；重新整理會清除尚未儲存的批次。閱讀／克漏字保留整個大題以維持文章連貫。

Gemini 僅取得伺服器產生的短教材代碼，回覆 Schema 限制來源只能使用這些代碼。伺服器檢查後才轉回原卡片 ID；不會忽略未登記來源或超範圍考點。答案僅有 A／B 等明確選項標號時會對應到該選項原文。格式或來源失敗最多自動修正一次，仍不合格會顯示具體題目與原因。

新增 `worker/exam-engine.mjs`；請連同整份 ZIP 上傳，不可只替換 HTML。`npm test` 包含 114 張卡／60 題的分批、來源檢查、自動修正及前端失敗接續測試。這些是模擬 Gemini 回傳的測試，尚未使用你的真實 API Key 重新出卷。

以自己的教材與學校考法，使用 Gemini 建立仿真練習卷。手機網頁介面，支援多檔教材辨識、人工校對、考卷樣式分析、出卷、線上作答、列印與帳號雲端同步。

**開始部署請閱讀 [SETUP.md](SETUP.md)。**

## 檔案用途

| 檔案 | 用途 |
| --- | --- |
| `index.html` | 相同介面的標準首頁名稱，供 GitHub Pages 靜態預覽使用 |
| `web/` | 可編輯的前端來源 |
| `worker/index.mjs` | API 後台：帳號、同步、檔案、Gemini 請求及回傳驗證 |
| `drizzle/0000_cloud_accounts.sql` | 空白資料庫的建表遷移，沒有真實帳號或教材資料 |
| `wrangler.toml` | Cloudflare 部署設定，需要填寫你自己的 D1 Database ID |
| `.dev.vars.example` | 本機 Google OAuth 設定範本，不含真實憑證 |
| `build.mjs` | 將前端內嵌到 Worker 部署檔 |
| `test-cloud.mjs` | 帳號隔離、檔案權限、同步衝突與 Gemini 契約測試 |

## GitHub 與部署

GitHub 可存放這份完整原始碼，也可透過 Cloudflare Workers Builds 連接 GitHub 自動部署。

GitHub Pages 只能提供靜態前端。**只把 HTML 放到 GitHub Pages，並不會同時取得登入、資料庫、檔案儲存或 AI 後台功能。** 本套件的完整部署採前後端同一個 Cloudflare Worker 網址，避免跨網域 Cookie 與 API 路由設定問題。HTML 沒有另外提供跨網域 API 位址設定。

本套件已移除原本 Sites 的專用登入連結、網站 ID 與身分標頭信任。部署到自己的 Cloudflare 帳戶後，使用 Email 或設定完成的 Google 帳號登入，不依賴原私人網站。

## 必須自行設定

- Cloudflare D1：帳號、教材卡片、考卷樣式、作答紀錄。
- Cloudflare R2：教材與考卷原檔；保持 Bucket 私有，由後台驗證下載權限。
- Gemini API Key：每位使用者在頁面下方自行輸入，僅留於當次分頁記憶體，不上傳到 GitHub 或長期保存。
- Google OAuth Web Client ID：管理者建立後設定 `GOOGLE_CLIENT_ID`，未設定時 Google 登入停用。

## 開發指令

需要 Node.js 24 或更新版本。

```sh
npm install
npm test
npm run db:local
npm run dev
```

先完成 SETUP.md 中的儲存資源與 Wrangler 設定。`wrangler dev` 會執行設定中的建置指令；本機與線上資料庫分開。

```sh
npm run build
npm run db:remote
npm run deploy
```

這份交付物已通過 Node 語法檢查、SQLite 帳號／隔離測試、Gemini 模擬上游契約與建置檢查。未在你的 Cloudflare 帳戶實際部署，亦未使用真實 Gemini Key 或 Google Client ID 完成推論／Google 登入驗證。

## 功能限制

- AI「學習考法」是分析考卷結構並於生成時引用，不會訓練或改動 Gemini 基礎模型。
- AI 文字辨識、自然語言範圍、題目與答案仍需人工校對。每批最多10檔、每檔8MB；每次出卷最多60題。
- Email 帳號目前沒有驗證信或忘記密碼寄信；不同登入方式的資料不會自動合併。
- ZIP 不包含原網站的資料庫、帳號、教材原檔或登入狀態；新部署從空白開始。原網站的純文字備份可依介面匯入，原始檔案需重新上傳。
- 本套件不會替你在 GitHub 建立儲存庫、公開網站或購買服務。

## 官方參考

- [Cloudflare Workers GitHub 自動部署](https://developers.cloudflare.com/workers/ci-cd/builds/)
- [D1 遷移](https://developers.cloudflare.com/d1/reference/migrations/)
- [R2 Bucket 建立](https://developers.cloudflare.com/r2/buckets/create-buckets/)
- [Gemini API Key](https://ai.google.dev/gemini-api/docs/api-key)
- [Google OAuth Client ID](https://developers.google.com/identity/gsi/web/guides/get-google-api-clientid)
- [GitHub Pages 說明](https://docs.github.com/en/pages/getting-started-with-github-pages/about-github-pages)


## 登入修正版補充（1.1）

直接開 HTML 或 GitHub Pages 是介面預覽，登入表單會停用。要在這台電腦實際測試帳號，不必先建立 Cloudflare 資源：安裝 Node.js 24 後，在專案目錄執行 `npm run preview:local`，再開啟 `http://127.0.0.1:4180/`。本機資料儲存在 `.local/`，不會上傳 GitHub，也不能跨裝置同步。

Google 登入需要真實 Web Client ID。本機測試可複製 `.dev.vars.example` 為 `.dev.vars`，填入 `GOOGLE_CLIENT_ID` 後重啟本機後台；Google 授權 JavaScript 來源需包含 `http://127.0.0.1:4180`（若用 localhost，也加入 `http://localhost:4180`）。正式網站則設定實際 HTTPS 網域。請用獨立視窗操作 Google 登入；內嵌視窗可能阻擋彈出視窗或 Cookie。沒有 Client ID 時不會顯示可用的 Google 按鈕。

修正版驗證本機 HTTP 與正式 HTTPS 的 Cookie、登入後保存狀態，以及 Google 簽章、nonce、audience、expiry。這不等同已在你的 Google 專案實際驗證通過，仍需完成 Client ID 與來源設定。下載程式碼的按鈕不會出現在網站內；請使用聊天回覆提供的下載連結。
