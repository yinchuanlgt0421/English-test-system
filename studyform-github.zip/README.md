# 範圍內 Studyform

以自己的教材與學校考法，使用 Gemini 建立仿真練習卷。手機網頁介面，支援多檔教材辨識、人工校對、考卷樣式分析、出卷、線上作答、列印與帳號雲端同步。

**開始部署請閱讀 [SETUP.md](SETUP.md)。**

## 檔案用途

| 檔案 | 用途 |
| --- | --- |
| `indec.html` | 依需求命名的單檔介面，已內嵌 CSS、JavaScript 與圖示；可直接開啟預覽 |
| `index.html` | 相同介面的標準首頁名稱，供 GitHub Pages 靜態預覽使用 |
| `web/` | 可編輯的前端來源 |
| `worker/index.mjs` | API 後台：帳號、同步、檔案、Gemini 請求及回傳驗證 |
| `drizzle/0000_cloud_accounts.sql` | 空白資料庫的建表遷移，沒有真實帳號或教材資料 |
| `wrangler.toml` | Cloudflare 部署設定，需要填寫你自己的 D1 Database ID |
| `.dev.vars.example` | 本機 Google OAuth 設定範本，不含真實憑證 |
| `build.mjs` | 將前端內嵌到 Worker 部署檔 |
| `test-cloud.mjs` | 帳號隔離、檔案權限、同步衝突與 Gemini 契約測試 |

## GitHub 與部署

GitHub 可存放這份完整原始碼，也可透過 Cloudflare Workers Builds 連接 GitHub 自動部署。

GitHub Pages 只能提供靜態前端。**只把 HTML 放到 GitHub Pages，並不會同時取得登入、資料庫、檔案儲存或 AI 後台功能。** 本套件的完整部署採前後端同一個 Cloudflare Worker 網址，避免跨網域 Cookie 與 API 路由設定問題。HTML 沒有另外提供跨網域 API 位址設定。

本套件已移除原本 Sites 的專用登入連結、網站 ID 與身分標頭信任。部署到自己的 Cloudflare 帳戶後，使用 Email 或設定完成的 Google 帳號登入，不依賴原私人網站。

## 必須自行設定

- Cloudflare D1：帳號、教材卡片、考卷樣式、作答紀錄。
- Cloudflare R2：教材與考卷原檔；保持 Bucket 私有，由後台驗證下載權限。
- Gemini API Key：每位使用者在頁面下方自行輸入，僅留於當次分頁記憶體，不上傳到 GitHub 或長期保存。
- Google OAuth Web Client ID：管理者建立後設定 `GOOGLE_CLIENT_ID`，未設定時 Google 登入停用。

## 開發指令

需要 Node.js 24 或更新版本。

```sh
npm install
npm test
npm run db:local
npm run dev
```

先完成 SETUP.md 中的儲存資源與 Wrangler 設定。`wrangler dev` 會執行設定中的建置指令；本機與線上資料庫分開。

```sh
npm run build
npm run db:remote
npm run deploy
```

這份交付物已通過 Node 語法檢查、SQLite 帳號／隔離測試、Gemini 模擬上游契約與建置檢查。未在你的 Cloudflare 帳戶實際部署，亦未使用真實 Gemini Key 或 Google Client ID 完成推論／Google 登入驗證。

## 功能限制

- AI「學習考法」是分析考卷結構並於生成時引用，不會訓練或改動 Gemini 基礎模型。
- AI 文字辨識、自然語言範圍、題目與答案仍需人工校對。每批最多10檔、每檔8MB；每次出卷最多60題。
- Email 帳號目前沒有驗證信或忘記密碼寄信；不同登入方式的資料不會自動合併。
- ZIP 不包含原網站的資料庫、帳號、教材原檔或登入狀態；新部署從空白開始。原網站的純文字備份可依介面匯入，原始檔案需重新上傳。
- 本套件不會替你在 GitHub 建立儲存庫、公開網站或購買服務。

## 官方參考

- [Cloudflare Workers GitHub 自動部署](https://developers.cloudflare.com/workers/ci-cd/builds/)
- [D1 遷移](https://developers.cloudflare.com/d1/reference/migrations/)
- [R2 Bucket 建立](https://developers.cloudflare.com/r2/buckets/create-buckets/)
- [Gemini API Key](https://ai.google.dev/gemini-api/docs/api-key)
- [Google OAuth Client ID](https://developers.google.com/identity/gsi/web/guides/get-google-api-clientid)
- [GitHub Pages 說明](https://docs.github.com/en/pages/getting-started-with-github-pages/about-github-pages)
