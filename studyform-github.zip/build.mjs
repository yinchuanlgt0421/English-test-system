import {readFileSync,writeFileSync,mkdirSync,readdirSync} from 'node:fs';
const logo='data:image/svg+xml;base64,'+Buffer.from(readFileSync('web/icon.svg')).toString('base64');
const manifest=JSON.parse(readFileSync('web/manifest.webmanifest','utf8'));manifest.icons[0].src=logo;
const manifestUrl='data:application/manifest+json;base64,'+Buffer.from(JSON.stringify(manifest)).toString('base64');
const css=readFileSync('web/style.css','utf8')+'\n'+readFileSync('web/upgrade.css','utf8');
const script=readFileSync('web/app.js','utf8').replaceAll('src="icon.svg"','src="'+logo+'"').replace(/<\/script/gi,'<\\/script');
const html=readFileSync('web/index.html','utf8')
  .replace('<link rel="stylesheet" href="style.css"><link rel="stylesheet" href="upgrade.css">',()=>'<style>'+css+'</style>')
  .replace('href="manifest.webmanifest"','href="'+manifestUrl+'"')
  .replace('href="icon.svg"','href="'+logo+'"')
  .replace('<script src="app.js?v=3"></script>',()=>'<script>'+script+'</script>');
writeFileSync('index.html',html);
const assets={};const types={html:'text/html; charset=utf-8',css:'text/css; charset=utf-8',js:'text/javascript; charset=utf-8',svg:'image/svg+xml',webmanifest:'application/manifest+json'};
for(const name of readdirSync('web'))assets['/'+name]={type:types[name.split('.').at(-1)]||'text/plain',body:readFileSync('web/'+name,'utf8')};
assets['/index.html']={type:'text/html; charset=utf-8',body:html};
mkdirSync('dist/server',{recursive:true});writeFileSync('dist/server/index.js','const ASSETS='+JSON.stringify(assets)+';\n'+readFileSync('worker/index.mjs','utf8'));
writeFileSync('dist/server/exam-engine.mjs',readFileSync('worker/exam-engine.mjs','utf8'));
console.log('Built standalone HTML and Cloudflare Worker.');
