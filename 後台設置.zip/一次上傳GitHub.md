# 只需要做一次：上傳 GitHub

這個 ZIP 已把 GitHub 入口頁和完整後台原始碼放在一起。

1. 將 ZIP 解壓縮。
2. 開啟你的 GitHub 儲存庫 `English-test-system`。
3. 選 **Add file → Upload files**，上傳解壓後「裡面的全部檔案及資料夾」，取代舊的 `index.html`。請勿只上傳 ZIP，也不要把所有檔案再包在一層資料夾中。
4. 按 **Commit changes**，等待 GitHub Pages 的部署工作顯示完成。
5. 開啟原本的 GitHub Pages 網址。它會自動前往已代管的完整網站，使用 Email 與密碼註冊／登入。

如果你已經啟用 GitHub Pages，通常不必更改設定。若未啟用，進入 **Settings → Pages → Deploy from a branch**，選擇你上傳的分支及 **/(root)**，儲存。

## 這份 ZIP 裡有什麼？

- `index.html`：可直接上傳的入口頁；在 GitHub Pages 或本機開啟都會前往完整網站。未自動前往時可按「開啟完整網站」。
- `.nojekyll`：讓 GitHub Pages 直接提供檔案。
- `hosted-site.json`：正式網站網址；沒有密碼或 API Key。
- `web/`、`worker/`、`drizzle/`、`build.mjs`、`wrangler.toml` 及測試：可自行架設後台的完整原始碼。
- `SETUP.md`：只有將來想改成自己管理後台時才需要閱讀。

GitHub Pages 只提供靜態檔案，不會執行 ZIP 裡的 Worker 或資料庫。此方案由 GitHub 提供入口，實際功能沿用已代管網站；瀏覽器網址會切換到完整網站，不是把後台搬進 GitHub。

入口不會搬移或清空帳號資料。資料仍保存在正式網站的個人帳號中；Gemini API Key 仍由每位使用者自行輸入。

完整網站：https://studyform-eric-20261021.exactvenus12.chatgpt.site/
