import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
const origin='http://127.0.0.1:4180';
const email='test-'+crypto.randomUUID()+'@example.invalid',password=crypto.randomUUID()+'!a';
let accountId;
try{
  const health=await fetch(origin+'/health');assert.equal((await health.json()).mode,'local');
  const res=await fetch(origin+'/api/auth/register',{method:'POST',headers:{origin,'content-type':'application/json'},body:JSON.stringify({email,password,name:'登入流程測試'})});
  assert.equal(res.status,200);const created=await res.json();accountId=created.user.id;
  const cookie=res.headers.getSetCookie().find(c=>c.startsWith('sf_session_local=')).split(';')[0];
  let r=await fetch(origin+'/api/me',{headers:{cookie}});assert.equal((await r.json()).user.id,accountId);
  r=await fetch(origin+'/api/state',{headers:{cookie}});assert.deepEqual((await r.json()).state,{folders:[],templates:[],exams:[]});
  r=await fetch(origin+'/api/auth/logout',{method:'POST',headers:{origin,cookie}});assert.equal(r.status,200);
  r=await fetch(origin+'/api/me',{headers:{cookie}});assert.equal((await r.json()).user,null);
  r=await fetch(origin+'/api/auth/login',{method:'POST',headers:{origin,'content-type':'application/json'},body:JSON.stringify({email,password})});assert.equal(r.status,200);
  r=await fetch(origin+'/download/index.html');assert.equal(r.headers.get('content-disposition'),'attachment; filename="index.html"');assert((await r.text()).includes('Gemini'));
  r=await fetch(origin+'/');const home=await r.text();assert(!home.includes('一鍵下載後台 ZIP'));assert(!home.includes('/download/backend.zip'));
  console.log('PASS: actual local HTTP signup, session persistence, empty account, logout/login, index.html download and no delivery buttons in app.');
}finally{
  if(accountId){const sql=new DatabaseSync('.local/studyform.sqlite');sql.prepare('DELETE FROM sf_sessions WHERE account_id=?').run(accountId);sql.prepare('DELETE FROM sf_states WHERE owner=?').run(accountId);sql.prepare('DELETE FROM sf_accounts WHERE id=?').run(accountId);sql.close()}
}
