import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import vm from 'node:vm';
import worker from './worker/index.mjs';
const sql=new DatabaseSync(':memory:');sql.exec(fs.readFileSync('drizzle/0000_cloud_accounts.sql','utf8'));
const DB={prepare(query){return {bind(...args){return {async first(){return sql.prepare(query).get(...args)||null},async run(){return {meta:{changes:Number(sql.prepare(query).run(...args).changes)}}}}}}}};
const origin='https://transport.test',env={DB},key='fake-key-for-browser-transport';
let res=await worker.fetch(new Request(origin+'/api/auth/register',{method:'POST',headers:{origin,'content-type':'application/json'},body:JSON.stringify({email:'browser@example.test',password:'browser-test-password-123'})}),env);
assert.equal(res.status,200);const cookie=res.headers.get('set-cookie').split(';')[0];
let googleCalls=0,serverCalls=0,queue=[],hostile=false;
const realFetch=globalThis.fetch;globalThis.fetch=async()=>{throw Error('Backend must not contact Google in browser mode')};
const fetcher=async(url,options)=>{
 if(String(url).startsWith('https://generativelanguage.googleapis.com/')){
  googleCalls++;assert.equal(options.headers['x-goog-api-key'],key);assert.equal(options.credentials,'omit');assert.equal(options.redirect,'error');
  const item=queue.shift();assert(item,'Unexpected extra Google request');return new Response(JSON.stringify(item.payload),{status:item.status||200,headers:{'content-type':'application/json'}});
 }
 serverCalls++;
 assert(!options.headers['x-gemini-api-key'],'API key must go only to Google');
 if(hostile)return new Response(JSON.stringify({browserRequest:{url:'https://attacker.invalid/steal',method:'GET'}}),{headers:{'content-type':'application/json'}});
 return worker.fetch(new Request(origin+url,{...options,headers:{...options.headers,origin,cookie}}),env);
};
let source=fs.readFileSync('web/app.js','utf8').replace(/\nboot\(\);\s*\n\}\)\(\);\s*$/,"\nglobalThis.testAPI=api;geminiKey='"+key+"';\n})();");
const context={document:{querySelector:()=>({addEventListener(){}})},window:{addEventListener(){}},location:{origin,protocol:'https:'},URL,fetch:fetcher,AbortSignal,FormData,Response,crypto,structuredClone,setTimeout,clearTimeout,console};vm.createContext(context);vm.runInContext(source,context);
const output=data=>({payload:{candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify(data)}]}}]}});
try{
 queue=[{payload:{models:[{name:'models/gemini-test',displayName:'Test',supportedGenerationMethods:['generateContent']}]}}];
 let result=await context.testAPI('/api/models',{method:'POST',ai:true});assert.equal(result.models[0].id,'gemini-test');assert.equal(googleCalls,1);assert.equal(serverCalls,2);
 queue=[{status:503,payload:{error:{status:'UNAVAILABLE',message:'Busy'}}},{payload:{models:[{name:'models/gemini-test',supportedGenerationMethods:['generateContent']}]}}];
 result=await context.testAPI('/api/models',{method:'POST',ai:true});assert.equal(result.models[0].id,'gemini-test');assert.equal(queue.length,0);
 queue=[output({summary:'ok',warnings:[],cards:[{word:'word1',meaning:'字1',example:'',kind:'vocabulary',sourceIndex:0,uncertain:false}]})];
 result=await context.testAPI('/api/ai',{method:'POST',ai:true,body:{task:'materials',model:'gemini-test',files:[{name:'words.txt',mime:'text/plain',data:btoa('word1')}]}});assert.equal(result.data.cards[0].word,'word1');
 queue=[output({name:'考卷',summary:'單選',minutes:30,warnings:[],sections:[{type:'choice',name:'單選',count:2,points:2,instruction:'選擇',example:'',difficulty:'中'}]})];
 result=await context.testAPI('/api/ai',{method:'POST',ai:true,body:{task:'style',model:'gemini-test',files:[{name:'exam.txt',mime:'text/plain',data:btoa('Question')}]}});assert.equal(result.data.sections[0].count,2);
 queue=[output({results:[{index:0,credit:1,feedback:'正確'}]})];
 result=await context.testAPI('/api/ai',{method:'POST',ai:true,body:{task:'grade',model:'gemini-test',questions:[{prompt:'word1',answer:'word1'}],answers:{0:'word1'}}});assert.equal(result.data.results[0].credit,1);
 const cards=Array.from({length:4},(_,i)=>({id:'original-'+i,word:'word'+(i+1),meaning:'字',kind:'vocabulary'}));
 const question=(i,source)=>({sectionIndex:0,type:'choice',context:'',prompt:'Choose word for context '+i,options:['word1','word2','word3','word4'],answer:'word1',acceptedAnswers:[],explanation:'教材依據',sourceIds:[source],targetWords:['word1']});
 queue=[output({questions:[question(1,'bad'),question(2,'bad')]}),output({questions:[question(1,'C1'),question(2,'C1')]})];
 result=await context.testAPI('/api/ai',{method:'POST',ai:true,body:{task:'exam',model:'gemini-test',cards,template:{name:'Test',sections:[{name:'單選',type:'choice',count:2,points:2}]}}});
 assert.equal(result.data.questions.length,2);assert.equal(result.repairCount,1);assert(result.data.questions.every(q=>q.sourceIds[0]==='original-0'));assert.equal(queue.length,0);
 hostile=true;const before=googleCalls;await assert.rejects(context.testAPI('/api/models',{method:'POST',ai:true}),/目標不正確/);assert.equal(googleCalls,before);
 console.log('PASS actual frontend/Worker round trip: browser models, OCR, exam repair and original source mapping; no backend Google fetch; rejects foreign destinations');
}finally{globalThis.fetch=realFetch;sql.close()}
