import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import worker from './worker/index.mjs';
const sql=new DatabaseSync(':memory:');sql.exec(fs.readFileSync('drizzle/0000_cloud_accounts.sql','utf8'));
const DB={prepare(query){return {bind(...args){return {async first(){return sql.prepare(query).get(...args)||null},async run(){return {meta:{changes:Number(sql.prepare(query).run(...args).changes)}}}}}}}};
const origin='https://models.test',env={DB};
let res=await worker.fetch(new Request(origin+'/api/auth/register',{method:'POST',headers:{origin,'content-type':'application/json'},body:JSON.stringify({email:'models@example.test',password:'models-test-password-123'})}),env);
assert.equal(res.status,200);const cookie=res.headers.get('set-cookie').split(';')[0];
const key='fake-secret-key-for-models-test',realFetch=globalThis.fetch,realWarn=console.warn;let logs=[];console.warn=value=>logs.push(String(value));
async function request(){return worker.fetch(new Request(origin+'/api/models',{method:'POST',headers:{origin,cookie,'x-gemini-api-key':key}}),env)}
try{
 for(const [status,reason,message] of [[400,'API_KEY_INVALID','API key not valid'],[403,'API_KEY_HTTP_REFERRER_BLOCKED','Requests from referer are blocked'],[403,'SERVICE_DISABLED','API is disabled']]){
  globalThis.fetch=async()=>new Response(JSON.stringify({error:{code:status,status:status===400?'INVALID_ARGUMENT':'PERMISSION_DENIED',message:message+' '+key,details:[{reason}]}}),{status,headers:{'content-type':'application/json'}});
  res=await request();assert.equal(res.status,502);const body=await res.text();assert(body.includes(reason));assert(body.includes('HTTP '+status));assert(!body.includes(key));assert(logs.every(log=>!log.includes(key)));
 }
 globalThis.fetch=async()=>new Response(JSON.stringify({models:[{name:'models/gemini-test',displayName:'Test',supportedGenerationMethods:['generateContent']}]}),{headers:{'content-type':'application/json'}});
 res=await request();assert.equal(res.status,200);assert.equal((await res.json()).models[0].id,'gemini-test');
 console.log('PASS model-list diagnostics: upstream key/service/source errors, successful list and credential redaction');
}finally{globalThis.fetch=realFetch;console.warn=realWarn;sql.close()}
