import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
import {DatabaseSync} from 'node:sqlite';

const root=path.dirname(fileURLToPath(import.meta.url));
execFileSync(process.execPath,['build.mjs'],{cwd:root,stdio:'inherit'});
const worker=(await import(pathToFileURL(path.join(root,'dist/server/index.js')).href)).default;
const local=path.join(root,'.local');fs.mkdirSync(local,{recursive:true});
const sql=new DatabaseSync(path.join(local,'studyform.sqlite'));sql.exec('PRAGMA journal_mode=WAL');
sql.exec('CREATE TABLE IF NOT EXISTS local_migrations(name TEXT PRIMARY KEY)');
for(const name of fs.readdirSync(path.join(root,'drizzle')).filter(n=>n.endsWith('.sql')).sort()){
  if(sql.prepare('SELECT name FROM local_migrations WHERE name=?').get(name))continue;
  sql.exec('BEGIN');
  try{sql.exec(fs.readFileSync(path.join(root,'drizzle',name),'utf8'));sql.prepare('INSERT INTO local_migrations(name) VALUES(?)').run(name);sql.exec('COMMIT')}catch(e){sql.exec('ROLLBACK');throw e}
}
const DB={
  prepare(statement){
    return {bind(...values){
      return {
        async first(){return sql.prepare(statement).get(...values)||null},
        async run(){return {meta:{changes:Number(sql.prepare(statement).run(...values).changes)}}}
      };
    }};
  }
};
const objectRoot=path.join(local,'files');fs.mkdirSync(objectRoot,{recursive:true});
function objectPath(key){const p=path.resolve(objectRoot,key);if(!p.startsWith(objectRoot+path.sep))throw Error('Invalid object key');return p}
const BUCKET={async put(key,stream){const p=objectPath(key);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,Buffer.from(await new Response(stream).arrayBuffer()))},async get(key){const p=objectPath(key);return fs.existsSync(p)?{body:fs.readFileSync(p)}:null},async delete(key){fs.rmSync(objectPath(key),{force:true})}};
const env={DB,BUCKET,RUNTIME_MODE:'local'};
function send(response,body,status=200,headers={}){response.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store',...headers});response.end(body)}
const server=http.createServer(async(req,res)=>{
  try{
    if(!['127.0.0.1:4180','localhost:4180'].includes(req.headers.host))return send(res,JSON.stringify({error:'請使用 localhost 或 127.0.0.1 開啟'}),403);
    const url=new URL(req.url,'http://'+req.headers.host);
    if(url.pathname==='/health')return send(res,JSON.stringify({ok:true,mode:'local'}));
    if(url.pathname==='/preview'||url.pathname==='/preview/')return send(res,'',302,{location:'/'});
    if(url.pathname==='/download/backend.zip')return send(res,fs.readFileSync(path.join(root,'..','studyform-github-後台設置.zip')),200,{'content-type':'application/zip','content-disposition':'attachment; filename="studyform-github.zip"'});
    if(['/download/index.html','/download/indec.html'].includes(url.pathname))return send(res,fs.readFileSync(path.join(root,'index.html')),200,{'content-type':'text/html; charset=utf-8','content-disposition':'attachment; filename="index.html"'});
    const chunks=[];let size=0;
    for await(const chunk of req){size+=chunk.length;if(size>25*1024*1024)return send(res,JSON.stringify({error:'資料超過25MB'}),413);chunks.push(chunk)}
    const headers=new Headers();for(const [key,value]of Object.entries(req.headers))if(value)headers.set(key,Array.isArray(value)?value.join(','):value);
    headers.set('cf-connecting-ip',req.socket.remoteAddress||'127.0.0.1');
    const request=new Request(url,{method:req.method,headers,body:['GET','HEAD'].includes(req.method)?undefined:Buffer.concat(chunks)});
    const response=await worker.fetch(request,env);
    res.statusCode=response.status;
    for(const [key,value]of response.headers)if(key!=='set-cookie')res.setHeader(key,value);
    const cookies=response.headers.getSetCookie();if(cookies.length)res.setHeader('set-cookie',cookies);
    res.end(Buffer.from(await response.arrayBuffer()));
  }catch(e){console.error('Local request failed:',e.message);send(res,JSON.stringify({error:'本機後台暫時無法處理，請查看終端機。'}),500)}
});
server.listen(4180,'127.0.0.1',()=>console.log('Studyform: http://127.0.0.1:4180/ (local accounts and files; Email registration and login)'));
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>server.close(()=>{sql.close();process.exit(0)}));
