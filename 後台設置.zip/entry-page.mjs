export function entryPage(target,logo){
  const url=new URL(target);
  if(url.protocol!=='https:'||url.username||url.password)throw Error('正式網站入口必須使用不含憑證的 HTTPS 網址');
  const href=url.href.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const js=JSON.stringify(url.href).replace(/</g,'\\u003c');
  return `<!doctype html>
<html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#42674e"><meta name="description" content="範圍內 Studyform 完整網站入口：Email 登入、教材保存及 AI 仿真出卷。"><title>範圍內 Studyform｜開啟完整網站</title><link rel="icon" href="${logo}"><style>*{box-sizing:border-box}body{margin:0;background:#f6f7f2;color:#18323a;font:16px/1.8 system-ui,-apple-system,"Microsoft JhengHei",sans-serif;min-height:100vh;display:grid;place-items:center;padding:24px}main{background:white;border:1px solid #dfe4d9;border-radius:20px;max-width:600px;width:100%;padding:40px}img{width:44px;height:44px}h1{font-size:26px;margin:16px 0 8px}p{color:#687a76}.button{display:inline-block;background:#42674e;color:white;padding:12px 24px;border-radius:10px;text-decoration:none;font-weight:600}.note{font-size:14px;margin-top:24px}a:focus-visible{outline:3px solid #b4cb78;outline-offset:4px}</style></head>
<body><main><img src="${logo}" alt="範圍內"><h1>範圍內 Studyform</h1><p id="entry-status">正在開啟完整網站…</p><a class="button" href="${href}">開啟完整網站 →</a><p class="note">這個 GitHub 網址是網站入口，登入、教材與考卷會在完整網站中使用及保存。</p><noscript><p>你的瀏覽器未啟用 JavaScript，請按上方按鈕開啟網站。</p></noscript></main>
<script>(()=>{try{location.replace(${js})}catch{document.getElementById('entry-status').textContent='請按下方按鈕開啟完整網站。'}})();</script></body></html>`;
}
