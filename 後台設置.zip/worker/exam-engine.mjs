const typeNames={choice:'選擇題',cloze:'克漏字／填空',rewrite:'句型改寫',short:'簡答',reading:'閱讀選擇'};
const text=(value,max=12000)=>typeof value==='string'&&value.trim().length>0&&value.length<=max;
const term=value=>String(value||'').normalize('NFKC').toLowerCase().replace(/[‘’]/g,"'").replace(/[‐‑–—]/g,'-').replace(/\s+/g,' ').trim();
function error(code,message){return Object.assign(new Error(message),{status:502,code})}
function invalid(code,message,index){throw error(code,`${Number.isInteger(index)?'第 '+(index+1)+' 題：':''}${message}`)}
export const questionSignature=q=>JSON.stringify([term(q.context),term(q.prompt),[...(q.options||[])].map(term).sort()]);

export function validateExam(data,input){
  const sections=input.template.sections,total=sections.reduce((n,s)=>n+s.count,0);
  if(!Array.isArray(data?.questions)||data.questions.length!==total)invalid('EXAM_COUNT',`題數不符，預期 ${total} 題，實際 ${data?.questions?.length||0} 題。`);
  const cards=new Map(input.cards.map(c=>[c.id,c]));
  const registeredTerms=new Set(input.cards.map(c=>term(c.word)));
  for(let si=0;si<sections.length;si++){
    const actual=data.questions.filter(q=>q.sectionIndex===si).length;
    if(actual!==sections[si].count)invalid('EXAM_SECTION_COUNT',`「${sections[si].name||'第'+(si+1)+'大題'}」題數不符：預期 ${sections[si].count} 題，實際 ${actual} 題。`);
  }
  for(let i=0;i<data.questions.length;i++){
    const q=data.questions[i],section=sections[q.sectionIndex];
    if(!section)invalid('EXAM_SECTION','大題編號不存在。',i);
    if(q.type!==section.type)invalid('EXAM_TYPE',`題型不符，預期${typeNames[section.type]||section.type}。`,i);
    if(!text(q.prompt))invalid('EXAM_PROMPT','缺少完整題目文字，或題目過長。',i);
    if(!text(q.answer))invalid('EXAM_ANSWER','缺少參考答案，或答案過長。',i);
    if(!text(q.explanation))invalid('EXAM_EXPLANATION','缺少詳細解答，或解答過長。',i);
    if(q.context!==undefined&&(typeof q.context!=='string'||q.context.length>30000))invalid('EXAM_CONTEXT','閱讀／克漏字文章格式不正確。',i);
    if(!Array.isArray(q.sourceIds)||!q.sourceIds.length)invalid('EXAM_SOURCE_MISSING','AI 未標註教材來源，無法確認已登記範圍。',i);
    if(q.sourceIds.some(id=>typeof id!=='string'||!cards.has(id)))invalid('EXAM_SOURCE_UNKNOWN','教材來源代碼不在已登記範圍，需重新對應。',i);
    if(!Array.isArray(q.options)||q.options.some(o=>!text(o,5000)))invalid('EXAM_OPTIONS','選項格式不完整。',i);
    if(['choice','reading'].includes(q.type)){
      if(q.options.length<2||q.options.length>6||new Set(q.options.map(term)).size!==q.options.length)invalid('EXAM_OPTIONS','選項數量不正確或有重複選項。',i);
      if(!q.options.includes(q.answer))invalid('EXAM_CHOICE_ANSWER','正確答案未對應任何選項。',i);
    }
    if(!Array.isArray(q.acceptedAnswers)||q.acceptedAnswers.some(a=>!text(a)))invalid('EXAM_ACCEPTED_ANSWERS','替代答案格式不正確。',i);
    if(!Array.isArray(q.targetWords)||q.targetWords.some(w=>typeof w!=='string'))invalid('EXAM_TARGETS','考點單字格式不正確。',i);
    const unknown=q.targetWords.find(w=>!registeredTerms.has(term(w)));
    if(unknown)invalid('EXAM_TARGET_OUT_OF_SCOPE',`考點「${unknown.slice(0,80)}」未登記在選定範圍。`,i);
  }
  return data;
}

export function examBatches(template,size=10){
  const batches=[];
  template.sections.forEach((section,sectionIndex)=>{
    const chunkSize=['cloze','reading'].includes(section.type)?section.count:size;
    for(let start=0;start<section.count;start+=chunkSize)batches.push({sectionIndex,start,count:Math.min(chunkSize,section.count-start)});
  });
  return batches;
}

export function prepareExamInput(input){
  if(!Array.isArray(input.cards)||!input.cards.length||input.cards.length>1000)throw Object.assign(Error('請選擇 1–1000 張已確認教材卡片。'),{status:400});
  if(input.cards.some(c=>!text(c.id,300)||!text(c.word,300)||!text(c.meaning)))throw Object.assign(Error('教材卡片缺少代碼、標題或內容，請先校對。'),{status:400});
  if(new Set(input.cards.map(c=>c.id)).size!==input.cards.length)throw Object.assign(Error('選定範圍含重複的卡片代碼，請先整理教材。'),{status:400});
  const originalByAlias=new Map(),aliasByOriginal=new Map();
  const cards=input.cards.map((c,i)=>{
    const id='C'+(i+1);originalByAlias.set(id,c.id);aliasByOriginal.set(c.id,id);
    return {id,word:c.word,meaning:c.meaning,example:c.example||'',kind:c.kind||'vocabulary'};
  });
  return {cards,originalByAlias,aliasByOriginal};
}

export function normalizeExam(data,prepared){
  if(!Array.isArray(data?.questions))return data;
  const termByCanonical=new Map(prepared.cards.map(c=>[term(c.word),c.word]));
  return {questions:data.questions.map(original=>{
    const q={...original};
    if(typeof q.sectionIndex==='string'&&/^\d+$/.test(q.sectionIndex))q.sectionIndex=Number(q.sectionIndex);
    for(const key of ['prompt','answer','explanation','context'])if(typeof q[key]==='string')q[key]=q[key].trim();
    if(q.context===undefined)q.context='';
    if(q.options===undefined)q.options=[];
    if(Array.isArray(q.options))q.options=q.options.map(o=>typeof o==='string'?o.trim():o);
    if(q.acceptedAnswers===undefined)q.acceptedAnswers=[];
    if(q.targetWords===undefined)q.targetWords=[];
    if(Array.isArray(q.sourceIds))q.sourceIds=[...new Set(q.sourceIds.map(id=>{
      if(typeof id!=='string')return id;
      const clean=id.trim(),alias=clean.toUpperCase();
      return prepared.originalByAlias.has(alias)?alias:prepared.aliasByOriginal.get(clean)||clean;
    }))];
    if(Array.isArray(q.targetWords))q.targetWords=q.targetWords.map(w=>termByCanonical.get(term(w))||w);
    if(['choice','reading'].includes(q.type)&&Array.isArray(q.options)&&q.options.every(o=>typeof o==='string')&&typeof q.answer==='string'){
      const direct=q.options.filter(o=>term(o)===term(q.answer));
      if(direct.length===1)q.answer=direct[0];
      else {
        const label=q.answer.match(/^\(?([A-F])\)?[.、:)：]?$/i);
        if(label&&q.options[label[1].toUpperCase().charCodeAt(0)-65])q.answer=q.options[label[1].toUpperCase().charCodeAt(0)-65];
        else {
          const strip=s=>term(s.replace(/^\(?[A-F]\)?[.、:)：]\s*/i,''));
          const exact=q.options.filter(o=>strip(o)===strip(q.answer));
          if(exact.length===1)q.answer=exact[0];
        }
      }
    }
    return q;
  })};
}

export async function generateExam(input,{invoke,schema,prompt}){
  const prepared=prepareExamInput(input),batches=examBatches(input.template),questions=[];
  const expected=input.template.sections.reduce((n,s)=>n+s.count,0);
  if(expected<1||expected>60)throw Object.assign(Error('每次請產生 1–60 題。'),{status:400});
  const previous=Array.isArray(input.previousQuestions)?input.previousQuestions.slice(-60):[];
  const seen=new Set(previous.map(questionSignature));let repairs=0;
  for(const batch of batches){
    const section=input.template.sections[batch.sectionIndex];
    const template={name:input.template.name,summary:input.template.summary||'',sections:[{...section,count:batch.count}]};
    const responseSchema=structuredClone(schema);
    responseSchema.properties.questions.minItems=batch.count;
    responseSchema.properties.questions.maxItems=batch.count;
    const qp=responseSchema.properties.questions.items.properties;
    qp.sourceIds={type:'array',minItems:1,maxItems:8,items:{type:'string',enum:[...prepared.originalByAlias.keys()]},description:'只能引用提供教材的 C1、C2 等代碼，不可自行創造或用單字當代碼。'};
    qp.type={type:'string',enum:[section.type]};
    qp.sectionIndex={type:'integer',minimum:0,maximum:0};
    const messages=[{role:'user',parts:[{text:prompt+'\n本次只生成這一批的 '+batch.count+' 題；sectionIndex 一律填 0。sourceIds 只使用 cards.id 的短代碼 C1、C2 等，不要使用單字或數字當代碼。每題至少一個來源。targetWords 只列實際被考核的單字卡 word 原文；筆記概念用 sourceIds 對應，不要把常用功能詞列為考點。每題必須有非空的 prompt、answer、explanation，勿省略。避免和已產生題目重複。'},{text:JSON.stringify({cards:prepared.cards,template,batch:{start:(input.batchOffset||0)+batch.start+1,count:batch.count},alreadyGenerated:[...previous,...questions].slice(-60).map(q=>({prompt:q.prompt,context:q.context||'',options:q.options||[]}))})}]}];
    let accepted;
    for(let attempt=0;attempt<2;attempt++){
      let raw;
      try{
        raw=await invoke({messages,schema:responseSchema,attempt});
        const candidate=normalizeExam(raw,prepared);
        validateExam(candidate,{cards:prepared.cards,template});
        const batchSeen=new Set();
        for(let qi=0;qi<candidate.questions.length;qi++){
          const signature=questionSignature(candidate.questions[qi]);
          if(seen.has(signature)||batchSeen.has(signature))invalid('EXAM_DUPLICATE','產生了重複題目，請更換情境與題幹。',qi);
          batchSeen.add(signature);
        }
        accepted=candidate.questions;break;
      }catch(e){
        if(!e.code?.startsWith('EXAM_')&&!['AI_JSON','AI_TRUNCATED'].includes(e.code))throw e;
        if(attempt===1)throw error(e.code,`「${section.name||'考卷'}」第 ${(input.batchOffset||0)+batch.start+1}–${(input.batchOffset||0)+batch.start+batch.count} 題校驗仍未通過：${e.message} 已完成題目會暫留此分頁，按產生可接續重試。`);
        repairs++;
        if(raw)messages.push({role:'model',parts:[{text:JSON.stringify(raw)}]});
        messages.push({role:'user',parts:[{text:'上次結果未通過檢查：'+e.message+'\n請修正後重新輸出完整這一批 '+batch.count+' 題，不要只補一題。範圍只限以上 cards，sourceIds 必須使用提供的 C 代碼。不要刪除來源檢查，也不要加入新教材。'}]});
      }
    }
    for(const q of accepted){
      seen.add(questionSignature(q));
      questions.push({...q,sectionIndex:batch.sectionIndex,sourceIds:q.sourceIds.map(id=>prepared.originalByAlias.get(id))});
    }
  }
  const result={questions};validateExam(result,input);
  return {data:result,repairCount:repairs,batches:batches.length};
}
