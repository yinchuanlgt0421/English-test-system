# 範圍內 Studyform · GitHub 一次上傳版

**先閱讀 [一次上傳GitHub.md](一次上傳GitHub.md)。解壓 ZIP，將裡面的所有檔案上傳到儲存庫根目錄，取代舊首頁。**

GitHub 網址會自動前往已代管的完整網站，使用 Email＋密碼註冊／登入。學生自行輸入 Gemini API Key 即可辨識教材、分析考卷樣式、出卷及作答。

正式網站：https://studyform-eric-20261021.exactvenus12.chatgpt.site/

## 一份 ZIP 包含

- 標準首頁 `index.html`：自動前往完整網站，另有手動開啟按鈕。
- `hosted-site.json`、`entry-page.mjs`：可維護的入口設定與產生器。
- `web/`、`worker/`、`drizzle/`：完整前端、登入／同步 API、出卷驗證、資料庫結構與檔案儲存邏輯。
- 建置腳本、部署設定與測試；沒有使用者資料庫、教材、帳號密碼或 API Key。

GitHub Pages 是靜態檔案服務。這份 ZIP 不會讓 GitHub 執行後台；最簡單的方式是把 GitHub 當入口，繼續使用已代管後台。網頁網址會切換至正式網站，帳號與資料不會搬移或清空。

## 想自行架設後台時

只有希望改用自己的後台時，才需要閱讀 [SETUP.md](SETUP.md)。設定好資源後，`npm run build` 會產生兩種結果：根目錄的入口頁，以及內含完整網頁和 API 的 Worker。Worker 首頁不是入口跳轉頁。

自行部署後可更新 `hosted-site.json` 的正式網址並重新建置，再更新 GitHub 入口。不要把 Gemini Key、登入資料或學生教材提交到 GitHub。

## 目前功能

Email 密碼帳號、個人資料同步、多檔教材上傳與校對、考卷樣式分析、仿真出卷、分批進度與接續、線上作答與列印。Google 登入已移除。AI 由使用者瀏覽器直接呼叫 Google，後台檢查回覆格式及教材來源。

Email 驗證信與忘記密碼寄信尚未提供。AI 自然語言內容仍應校對。
