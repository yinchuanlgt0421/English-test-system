# 範圍內 Studyform

## 1.3.1 Gemini 連線修正

2026-10-23 實際查到代管後台向 Google 取得模型清單時收到 HTTP 400 / FAILED_PRECONDITION：User location is not supported for the API use。改由使用者瀏覽器直接呼叫 Gemini，本站後台準備請求並驗證回傳格式、題型與教材來源；模型清單、教材／考卷辨識、出卷與批改均採相同通道。金鑰不送到本站後台，也不存入帳號或下載包。

瀏覽器連線仍需符合 Google 的服務地區、帳號、金鑰與額度規定。本版沒有付費代理、VPN 或第三方轉送服務。使用者需在更新後重新貼上自己的金鑰，真實瀏覽器推論仍需完成該次連線驗證。

## 1.3 Email 登入版

已移除 Google 登入按鈕、SDK、OAuth 設定與登入端點。使用顯示名稱、Email 及至少10字元密碼註冊，之後以相同 Email 和密碼登入。保留現有 Email 帳號、教材及考卷資料。Gemini API Key 仍由每位使用者自行輸入，用於辨識與出卷。

## 1.2.1 出卷修正

真實連線已確認 Gemini 3.8 Flash 可能回傳 HTTP 503 / UNAVAILABLE（模型需求過高）。出卷後台現在針對暫時性 HTTP 408、429、500、502、503、504 與網路中斷，採最多三次、受總時間限制的延遲重試，並遵守 Retry-After；不會對無效金鑰、權限或參數錯誤重試。最終錯誤顯示 Google 狀態與具體原因，且遮蔽金鑰。出卷移除不必要的 temperature 覆寫。

2026-10-21 已在本機使用實際 Gemini 3.8 Flash，從使用者的 114 張教材卡片完成 60 題單選卷；過程遇到 503 後，保留已完成 40 題並接續完成及存檔。已核對 60 題的選項、答案、詳解及來源 ID。這次實際推論驗證不代表已部署至使用者的 Cloudflare。

60 題選擇卷改為每批 10 題，介面顯示完成進度。同一分頁若中途失敗，可維持原範圍、樣式與名稱接續重試，已完成批次不重生；重新整理會清除尚未儲存的批次。閱讀／克漏字保留整個大題以維持文章連貫。

Gemini 僅取得伺服器產生的短教材代碼，回覆 Schema 限制來源只能使用這些代碼。伺服器檢查後才轉回原卡片 ID；不會忽略未登記來源或超範圍考點。答案僅有 A／B 等明確選項標號時會對應到該選項原文。格式或來源失敗最多自動修正一次，仍不合格會顯示具體題目與原因。

新增 `worker/exam-engine.mjs`；請連同整份 ZIP 上傳，不可只替換 HTML。`npm test` 包含 114 張卡／60 題的分批、來源檢查、自動修正及前端失敗接續測試；`test-gemini.mjs` 另外驗證暫時性錯誤的重試、Retry-After 與金鑰遮蔽。自動測試模擬上游回傳；另已完成上述實際 Gemini 出卷驗證。

以自己的教材與學校考法，使用 Gemini 建立仿真練習卷。手機網頁介面，支援多檔教材辨識、人工校對、考卷樣式分析、出卷、線上作答、列印與帳號雲端同步。

**開始部署請閱讀 [SETUP.md](SETUP.md)。**

## 檔案用途

| 檔案 | 用途 |
| --- | --- |
| `index.html` | 相同介面的標準首頁名稱，供 GitHub Pages 靜態預覽使用 |
| `web/` | 可編輯的前端來源 |
| `worker/index.mjs` | API 後台：帳號、同步、檔案、Gemini 請求及回傳驗證 |
| `drizzle/0000_cloud_accounts.sql` | 空白資料庫的建表遷移，沒有真實帳號或教材資料 |
| `wrangler.toml` | Cloudflare 部署設定，需要填寫你自己的 D1 Database ID |
| `.dev.vars.example` | 本機環境範本，不需額外登入金鑰 |
| `build.mjs` | 將前端內嵌到 Worker 部署檔 |
| `test-cloud.mjs` | 帳號隔離、檔案權限、同步衝突與 Gemini 契約測試 |

## GitHub 與部署

GitHub 可存放這份完整原始碼，也可透過 Cloudflare Workers Builds 連接 GitHub 自動部署。

GitHub Pages 只能提供靜態前端。**只把 HTML 放到 GitHub Pages，並不會同時取得登入、資料庫、檔案儲存或 AI 後台功能。** 本套件的完整部署採前後端同一個 Cloudflare Worker 網址，避免跨網域 Cookie 與 API 路由設定問題。HTML 沒有另外提供跨網域 API 位址設定。

本套件已移除原本 Sites 的專用登入連結、網站 ID 與身分標頭信任。部署到自己的 Cloudflare 帳戶後，使用 Email 與密碼登入，不依賴原私人網站。

## 必須自行設定

- Cloudflare D1：帳號、教材卡片、考卷樣式、作答紀錄。
- Cloudflare R2：教材與考卷原檔；保持 Bucket 私有，由後台驗證下載權限。
- Gemini API Key：每位使用者在頁面下方自行輸入，僅留於當次分頁記憶體，不上傳到 GitHub 或長期保存。

## 開發指令

需要 Node.js 24 或更新版本。

```sh
npm install
npm test
npm run db:local
npm run dev
```

先完成 SETUP.md 中的儲存資源與 Wrangler 設定。`wrangler dev` 會執行設定中的建置指令；本機與線上資料庫分開。

```sh
npm run build
npm run db:remote
npm run deploy
```

這份交付物已通過 Node 語法檢查、SQLite 帳號／隔離測試、Gemini 模擬上游契約、重試與建置檢查，並已在本機完成實際 Gemini 60 題出卷及存檔。未在你的 Cloudflare 帳戶實際部署。

## 功能限制

- AI「學習考法」是分析考卷結構並於生成時引用，不會訓練或改動 Gemini 基礎模型。
- AI 文字辨識、自然語言範圍、題目與答案仍需人工校對。每批最多10檔、每檔8MB；每次出卷最多60題。
- Email 帳號目前沒有驗證信或忘記密碼寄信；不同登入方式的資料不會自動合併。
- ZIP 不包含原網站的資料庫、帳號、教材原檔或登入狀態；新部署從空白開始。原網站的純文字備份可依介面匯入，原始檔案需重新上傳。
- 本套件不會替你在 GitHub 建立儲存庫、公開網站或購買服務。

## 官方參考

- [Cloudflare Workers GitHub 自動部署](https://developers.cloudflare.com/workers/ci-cd/builds/)
- [D1 遷移](https://developers.cloudflare.com/d1/reference/migrations/)
- [R2 Bucket 建立](https://developers.cloudflare.com/r2/buckets/create-buckets/)
- [Gemini API Key](https://ai.google.dev/gemini-api/docs/api-key)
- [GitHub Pages 說明](https://docs.github.com/en/pages/getting-started-with-github-pages/about-github-pages)


## 登入修正版補充（1.1）

直接開 HTML 或 GitHub Pages 是介面預覽，登入表單會停用。要在這台電腦實際測試帳號，不必先建立 Cloudflare 資源：安裝 Node.js 24 後，在專案目錄執行 `npm run preview:local`，再開啟 `http://127.0.0.1:4180/`。本機資料儲存在 `.local/`，不會上傳 GitHub，也不能跨裝置同步。


已驗證本機 HTTP 與正式 HTTPS Cookie、Email 註冊／登入、錯誤密碼拒絕、登出與帳號隔離。下載連結只放在聊天回覆。
