import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import worker from './worker/index.mjs';
for(const scenario of [503,429,404]){
const sql=new DatabaseSync(':memory:');sql.exec(fs.readFileSync('drizzle/0000_cloud_accounts.sql','utf8'));
const env={DB:{prepare(query){return {bind(...args){return {async first(){return sql.prepare(query).get(...args)||null},async run(){return {meta:{changes:Number(sql.prepare(query).run(...args).changes)}}}}}}}}};
const origin='https://recovery.test';
let response=await worker.fetch(new Request(origin+'/api/auth/register',{method:'POST',headers:{origin,'content-type':'application/json'},body:JSON.stringify({email:'recovery@example.test',password:'recovery-test-password'})}),env);
assert.equal(response.status,200);const cookie=response.headers.get('set-cookie').split(';')[0];
const cards=Array.from({length:69},(_,i)=>({id:'original-'+i,word:'word'+(i+1),meaning:'字'+(i+1),kind:'vocabulary'}));
const fixture={folders:[{id:'f1',name:'69張測試範圍',cards}],templates:[{id:'t1',name:'20題樣式',summary:'原考卷60題；本次20題',minutes:30,sections:[{name:'單選',type:'choice',count:20,points:5}]}],exams:[]};
const call=(path,options={})=>worker.fetch(new Request(origin+path,{...options,headers:{...options.headers,origin,cookie}}),env);
response=await call('/api/state',{method:'PUT',headers:{'content-type':'application/json'},body:JSON.stringify({revision:0,state:fixture})});assert.equal(response.status,200);
const fields={};const field=s=>fields[s]||(fields[s]={innerHTML:'',textContent:'',value:'',checked:false,dataset:{},style:{},addEventListener(){},querySelector:()=>field('#status')});
field('#template-select').value='t1';field('#exam-name').value='20題故障復原測試';field('#auto-fallback').checked=true;
const document={querySelector:field,querySelectorAll:s=>s==='[name=scope]:checked'?[{value:'f1'}]:[]};
const storage=new Map(),sessionStorage={getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)};
let primaryCalls=0,alternateCalls=0,droppedValidation=false,droppedSave=false;const phases=[];
const fetcher=async(url,options={})=>{
 if(String(url).startsWith('https://generativelanguage.googleapis.com/')){
   assert.equal(options.headers['x-goog-api-key'],'fake-browser-key-only');
   if(String(url).includes('gemini-3.8-flash')){primaryCalls++;return new Response(JSON.stringify({error:{status:scenario===503?'UNAVAILABLE':scenario===429?'RESOURCE_EXHAUSTED':'NOT_FOUND',message:scenario===503?'high demand':scenario===429?'Generate content requests per day limit exceeded. limit: 20. Please retry in 4h44m5s.':'Model unavailable to new users'}}),{status:scenario,headers:{'content-type':'application/json'}})}
   assert(String(url).includes('gemini-3.5-flash-lite'));alternateCalls++;
   const input=JSON.parse(JSON.parse(options.body).contents[0].parts[1].text);
   assert.equal(input.cards.length,69);assert.equal(input.template.sections[0].count,10);
   const questions=Array.from({length:10},(_,i)=>({sectionIndex:0,type:'choice',context:'',prompt:'Choose the word for scenario '+(input.batch.start+i),options:['word1','word2','word3','word4'],answer:'A',acceptedAnswers:[],explanation:'對應教材 word1',sourceIds:['C1'],targetWords:['word1']}));
   return new Response(JSON.stringify({candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify({questions})}]}}]}),{headers:{'content-type':'application/json'}});
 }
 assert(!options.headers?.['x-gemini-api-key']);assert(!String(options.body).includes('fake-browser-key-only'));
 const body=options.body?JSON.parse(options.body):{};
 if(url==='/api/ai'&&body.browserResponses?.some(r=>r.status===200)&&!droppedValidation){droppedValidation=true;throw TypeError('Lost backend validation connection')}
 const result=await call(url,options);
 if(url==='/api/state'&&options.method==='PUT'&&!droppedSave){droppedSave=true;assert.equal(result.status,200);throw TypeError('Lost acknowledgement after saving')}
 return result;
};
const realFetch=globalThis.fetch;globalThis.fetch=()=>{throw Error('Backend Google fetch is forbidden in browser mode')};
try{
 const context={document,sessionStorage,window:{addEventListener(){},scrollTo(){}},location:{protocol:'https:',pathname:'/',origin},fetch:fetcher,AbortSignal,FormData,Response,URL,structuredClone,crypto,console,setTimeout:(f,ms)=>setTimeout(f,Math.min(ms,1)),clearTimeout};
 vm.createContext(context);
 let source=fs.readFileSync('web/app.js','utf8').replace(/\nboot\(\);\s*\n\}\)\(\);\s*$/,`\nglobalThis.prepare=async()=>{await boot();geminiKey='fake-browser-key-only';model='gemini-3.8-flash';models=[{id:'gemini-3.8-flash'},{id:'gemini-3.5-flash-lite'},{id:'gemini-2.5-flash'}];};\n})();`);
 vm.runInContext(source,context);await context.prepare();
 await field('#generate-form').onsubmit({preventDefault(){}});
 response=await call('/api/state');const saved=(await response.json()).state;
 assert.equal(saved.exams.length,1);assert.equal(saved.exams[0].questions.length,20);assert.equal(saved.exams[0].totalPoints,100);assert.equal(saved.exams[0].aiModel,'gemini-3.5-flash-lite');assert.equal(saved.aiPreferences.model,'gemini-3.5-flash-lite');
 assert(saved.exams[0].questions.every(q=>q.sourceIds[0]==='original-0'&&q.answer==='word1'));
 assert.equal(primaryCalls,scenario===503?4:1);assert.equal(alternateCalls,2,'Backend disconnect must not duplicate Google generation');assert(droppedValidation&&droppedSave);assert.equal(storage.size,0);
 console.log('PASS 69 cards / 20 questions: '+scenario+' -> current Flash-Lite fallback, dropped validation, lost save acknowledgement, strict scope and exact 100 points; remembers successful model, one cloud exam, no key sent to backend or storage.');
}finally{globalThis.fetch=realFetch;sql.close()}
}
