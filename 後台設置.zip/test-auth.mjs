import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import vm from 'node:vm';
import worker from './worker/index.mjs';
const sql=new DatabaseSync(':memory:');sql.exec(fs.readFileSync('drizzle/0000_cloud_accounts.sql','utf8'));
const DB={prepare(statement){return {bind(...values){return {
  async first(){return sql.prepare(statement).get(...values)||null},
  async run(){return {meta:{changes:Number(sql.prepare(statement).run(...values).changes)}}}
}}}}};
const env={DB};
async function call(path,body,{origin='https://studyform.test',cookies='',method='POST'}={}){
  return worker.fetch(new Request(origin+path,{method,headers:{origin,cookie:cookies,'content-type':'application/json'},body:method==='GET'?undefined:JSON.stringify(body||{})}),env);
}
let res=await call('/api/auth/register',{email:'auth@example.com',password:'valid-password-123',name:'測試'});assert.equal(res.status,200);
assert(res.headers.get('set-cookie').includes('__Host-sf_session='));assert(res.headers.get('set-cookie').includes('Secure;'));assert(res.headers.get('set-cookie').includes('SameSite=Lax'));
res=await call('/api/auth/register',{email:'auth@example.com',password:'valid-password-123'});assert.equal(res.status,409);
res=await call('/api/auth/login',{email:'auth@example.com',password:'valid-password-123'},{origin:'http://127.0.0.1:4180'});assert.equal(res.status,200);
const localCookie=res.headers.get('set-cookie').split(';')[0];assert(localCookie.startsWith('sf_session_local='));assert(!res.headers.get('set-cookie').includes('Secure;'));
res=await call('/api/me',null,{origin:'http://127.0.0.1:4180',cookies:localCookie,method:'GET'});assert.equal((await res.json()).user.email,'auth@example.com');
res=await call('/api/me',null,{cookies:localCookie,method:'GET'});assert.equal((await res.json()).user,null);
for(const path of ['/api/google/nonce','/api/auth/google']){res=await call(path,{});assert.equal(res.status,404)}
res=await call('/api/auth/login',{email:'auth@example.com',password:'wrong-password-123'});assert.equal(res.status,401);
res=await call('/api/auth/logout',{}, {origin:'http://127.0.0.1:4180',cookies:localCookie});assert.equal(res.status,200);
res=await call('/api/me',null,{origin:'http://127.0.0.1:4180',cookies:localCookie,method:'GET'});assert.equal((await res.json()).user,null);
const root={innerHTML:''},fields={},modal={addEventListener(){}};
const context={document:{querySelector:s=>s==='#app'?root:s==='#modal'?modal:fields[s]||(fields[s]={}),querySelectorAll:()=>[]},window:{addEventListener(){},scrollTo(){}},location:{protocol:'https:',pathname:'/',origin:'https://example.github.io'},fetch:async()=>new Response('<html>404</html>',{status:404}),AbortSignal,crypto,structuredClone,FormData,Response,setTimeout,clearTimeout};
vm.createContext(context);vm.runInContext(fs.readFileSync('web/app.js','utf8'),context);await new Promise(r=>setTimeout(r,30));assert(root.innerHTML.includes('目前尚未連接登入後台'));assert(!root.innerHTML.includes('id="register-form"'));assert(!root.innerHTML.includes('id="login-form"'));
console.log('PASS: local HTTP cookies, production secure cookies, duplicate registration, Email password rejection, logout, removed OAuth routes, static preview blocks unusable login forms.');
sql.close();
