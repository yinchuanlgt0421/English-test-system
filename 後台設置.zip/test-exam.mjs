import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';
import {generateExam,prepareExamInput,normalizeExam,validateExam,examBatches} from './worker/exam-engine.mjs';
const cards=Array.from({length:114},(_,i)=>({id:crypto.randomUUID(),word:'word'+(i+1),meaning:'意思'+(i+1),kind:'vocabulary',example:''}));
const template={id:'t1',name:'60題單選考卷',summary:'單字選擇',minutes:30,sections:[{name:'單選題',type:'choice',count:60,points:2}]};
const schema={type:'object',properties:{questions:{type:'array',items:{type:'object',properties:{}}}}};
const question=(index,extra={})=>({sectionIndex:0,type:'choice',context:'',prompt:'Question '+index,options:['word1','word2','word3','word4'],answer:'word1',acceptedAnswers:[],explanation:'依據已登記卡片 word1。',sourceIds:['C1'],targetWords:['word1'],...extra});
let calls=0;
const generated=await generateExam({cards,template},{schema,prompt:'test',invoke:async ({messages,schema:responseSchema,attempt})=>{
  calls++;const input=JSON.parse(messages[0].parts[1].text),n=responseSchema.properties.questions.minItems;
  assert.equal(input.cards[0].id,'C1');assert.equal(input.cards.length,114);assert(!JSON.stringify(input.cards).includes(cards[0].id));
  assert.equal(responseSchema.properties.questions.items.properties.sourceIds.items.enum.length,114);
  return {questions:Array.from({length:n},(_,i)=>question(input.batch.start+i,{sourceIds:calls===1?['C9999']:['C1'],answer:'A'}))};
}});
assert.equal(calls,7);assert.equal(generated.batches,6);assert.equal(generated.repairCount,1);assert.equal(generated.data.questions.length,60);
assert(generated.data.questions.every(q=>q.sourceIds[0]===cards[0].id&&q.answer==='word1'));
assert.equal(new Set(generated.data.questions.map(q=>q.prompt)).size,60);
let rejectedCalls=0;
await assert.rejects(()=>generateExam({cards,template:{...template,sections:[{...template.sections[0],count:1}]}},{schema,prompt:'test',invoke:async()=>{rejectedCalls++;return {questions:[question(1,{sourceIds:[]})]}}}),e=>e.code==='EXAM_SOURCE_MISSING'&&e.message.includes('未標註教材來源'));
assert.equal(rejectedCalls,2);
const one={cards:[{id:'C1',word:'word1'}],template:{sections:[{type:'choice',count:1}]}};
assert.throws(()=>validateExam({questions:[question(1,{explanation:''})]},one),e=>e.code==='EXAM_EXPLANATION'&&!e.message.includes('範圍'));
assert.throws(()=>validateExam({questions:[question(1,{targetWords:['outside']})]},one),e=>e.code==='EXAM_TARGET_OUT_OF_SCOPE');
assert.throws(()=>validateExam({questions:[question(1,{sourceIds:['unknown']})]},one),e=>e.code==='EXAM_SOURCE_UNKNOWN');
const normalized=normalizeExam({questions:[question(1,{sourceIds:[' c1 '],answer:'B.',targetWords:['WORD1']})]},prepareExamInput({cards}));
assert.equal(normalized.questions[0].answer,'word2');assert.equal(normalized.questions[0].sourceIds[0],'C1');assert.equal(normalized.questions[0].targetWords[0],'word1');
assert.equal(examBatches({sections:[{type:'cloze',count:15}]}).length,1);

// Exercise the actual browser generation handler: fail batch three, retain the
// first twenty questions, then resume without generating those batches again.
const app={innerHTML:''},modal={addEventListener(){}},fields={};
function field(s){return fields[s]||(fields[s]={innerHTML:'',textContent:'',value:'',dataset:{},style:{},querySelector:()=>field('#form-status')})}
field('#template-select').value='t1';field('#exam-name').value='測試60題';
const document={querySelector:s=>s==='#app'?app:s==='#modal'?modal:field(s),querySelectorAll:s=>s==='[name=scope]:checked'?[{value:'f1'}]:[]};
let aiCalls=0,saved=null,revision=0,failed=false,writeCalls=0;const offsets=[];
const storage=new Map(),sessionStorage={getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)};
const json=data=>new Response(JSON.stringify(data),{headers:{'content-type':'application/json'}});
const fakeFetch=async (url,options={})=>{
  if(url==='/api/me')return json({user:{id:'u1',name:'測試',provider:'password'},googleClientId:'',deployment:'cloud'});
  if(url==='/api/state'&&options.method==='PUT'){writeCalls++;saved=JSON.parse(options.body).state;++revision;throw TypeError('Injected lost response after database commit')}
  if(url==='/api/state')return json({state:saved||{folders:[{id:'f1',name:'測試範圍',cards}],templates:[template],exams:[]},revision});
  if(url==='/api/ai'){
    const input=JSON.parse(options.body);aiCalls++;offsets.push(input.batchOffset);
    if(input.batchOffset===20&&!failed){failed=true;return new Response(JSON.stringify({error:'模擬這一批來源校驗失敗',code:'EXAM_SOURCE_MISSING'}),{status:502,headers:{'content-type':'application/json'}})}
    assert.equal(input.previousQuestions.length,input.batchOffset);
    return json({data:{questions:Array.from({length:input.template.sections[0].count},(_,i)=>question(input.batchOffset+i+1,{sourceIds:[cards[0].id]}))},repairCount:0,model:input.model});
  }
  throw Error('Unexpected request '+url);
};
const context={document,sessionStorage,window:{addEventListener(){},scrollTo(){}},location:{protocol:'https:',pathname:'/',origin:'https://studyform.test'},fetch:fakeFetch,AbortSignal,FormData,Response,structuredClone,crypto,console,setTimeout:(f,ms)=>setTimeout(f,Math.min(ms,10)),clearTimeout};
vm.createContext(context);vm.runInContext(fs.readFileSync('web/app.js','utf8'),context);await new Promise(r=>setTimeout(r,30));
field('#gemini-key').oninput({target:{value:'fake-key-for-test'}});
await field('#generate-form').onsubmit({preventDefault(){}});
assert.equal(aiCalls,3);assert(field('#generate-status').textContent.includes('20 / 60'));assert.equal(saved,null);
assert(storage.size===1);assert(![...storage.values()].join('').includes('fake-key-for-test'));
// Reload the actual frontend in a fresh VM while retaining only sessionStorage.
const fresh={...context};vm.createContext(fresh);vm.runInContext(fs.readFileSync('web/app.js','utf8'),fresh);await new Promise(r=>setTimeout(r,30));
field('#gemini-key').oninput({target:{value:'fake-key-for-test'}});
field('#gemini-model').onchange({target:{value:'gemini-alternate-flash'}});
await field('#generate-form').onsubmit({preventDefault(){}});
assert(saved.exams[0].aiModel.includes('gemini-alternate-flash'));
assert.deepEqual(offsets,[0,10,20,20,30,40,50]);assert.equal(saved.exams.length,1);assert.equal(saved.exams[0].questions.length,60);
assert.equal(writeCalls,1,'Lost save response must be reconciled without a duplicate write');assert.equal(storage.size,0);
assert(saved.exams[0].questions.every(q=>q.sourceIds[0]===cards[0].id&&q.points===2));
console.log('PASS: 114-card/60-question generation, six batches, source aliases mapped to original IDs, bounded repair, precise diagnostics, choice-label normalization, strict scope guards, frontend progress and resume after failed batch.');
