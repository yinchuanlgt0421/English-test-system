# 自行架設後台（進階）

如果只想讓 GitHub 網址可以正常使用，請看 [一次上傳GitHub.md](一次上傳GitHub.md)，不用執行下面的 Cloudflare 設定。以下適用於將來要把後台移到自己帳戶的情況。

這份教學將原始碼放在 GitHub，實際網站部署到你自己的 Cloudflare Worker。前端、登入與資料保存 API 使用同一個 HTTPS 網址；Gemini 由使用者瀏覽器直接呼叫。你不需要把 API Key 直接寫進 HTML。

## 1. 解壓縮並上傳 GitHub

1. 解壓 ZIP，確認能看到 `README.md`、`index.html`、`package.json`、`wrangler.toml`、`web/`、`worker/`、`drizzle/`。
2. 在 GitHub 建立儲存庫，例如 `studyform`，初次可選私人。
3. 在儲存庫使用 **Add file → Upload files**，將「解壓後的檔案與資料夾」上傳；不要只上傳 ZIP，也不要多包一層資料夾。
4. 請勿上傳自己的 `.dev.vars`、`.env`、API Key、Cloudflare Token、資料庫備份或學生教材。
5. `index.html` 是唯一標準首頁檔名。目前根目錄 HTML 是正式網站入口；GitHub Pages 會自動前往正式網站。

## 2. 安裝本機工具

安裝 Node.js 24 或更新版本，開啟終端機並切換到解壓後的專案資料夾，執行：

```sh
npm install
npx wrangler login
```

依瀏覽器畫面登入你自己的 Cloudflare 帳戶。`npm install` 會產生 `package-lock.json`，建議一併提交到 GitHub 以固定依賴版本。

## 3. 建立資料庫與檔案儲存

可先從 Cloudflare 控制台建立，或使用下列 CLI：

```sh
npx wrangler d1 create studyform-db
npx wrangler r2 bucket create studyform-files
```

D1 建立後會顯示 Database ID。R2 需先在 Cloudflare 帳戶啟用；服務資格、是否需要付款設定及費用，以 Cloudflare 畫面為準。

編輯 `wrangler.toml`：

```toml
[[d1_databases]]
binding = "DB"
database_name = "studyform-db"
database_id = "填入你剛建立的真實D1-UUID"
migrations_dir = "drizzle"

[[r2_buckets]]
binding = "BUCKET"
bucket_name = "studyform-files"
```

請替換原本 `REPLACE_WITH_YOUR_D1_DATABASE_ID`。若使用自己的資源名稱，對應修改 `database_name`、`bucket_name`；程式使用的 `DB`、`BUCKET` 綁定名稱需保留。

若 Wrangler 建立資源時自動加入設定，請整理成各一個 DB／BUCKET 區塊，不要保留重複綁定。R2 不需要公開，不要啟用 Public Bucket。

## 4. 初始化資料庫、驗證及第一次部署

```sh
npm test
npm run db:remote
npm run deploy
```

`db:remote` 會在你的線上 D1 套用 `drizzle/` 遷移。`deploy` 會自動執行建置並部署 Worker；完成後會顯示你自己的 `https://...workers.dev` 網址。

第一次開啟應顯示登入／註冊頁。先用 Email 註冊，即可建立自己的學習空間。這個版本不會信任使用者自行夾帶的舊 Sites 身分標頭。

若看到「雲端資料庫尚未就緒」或伺服器錯誤，確認 D1 綁定名稱、Database ID、遷移結果及 Worker 日誌。未完成資料庫遷移時不要只重複上傳 HTML。

## 5. Email 註冊與登入

開啟部署好的網站，輸入顯示名稱、Email 及至少10字元密碼即可註冊。後續以相同 Email 和密碼登入。此版尚未提供驗證信與忘記密碼寄信功能，請保管密碼並定期匯出備份。

## 6. 設定 Gemini

1. 使用者到 [Google AI Studio API Keys](https://aistudio.google.com/api-keys) 建立自己的 Key。
2. 在你的網站下方「Gemini AI 工作台」貼上 Key，按「測試連線」。
3. 選可用模型，再建立資料夾、上傳多個教材並校對。
4. 上傳完整考卷頁面，校對樣式，最後選擇範圍與樣式產生仿卷。

Key 僅保存在當次分頁記憶體，每次重開需重新輸入。不要將自己的 Key 提交到 GitHub。辨識與出卷會使用該 Key 所屬專案的額度。

## 7. 連接 GitHub 自動更新

建議完成一次本機部署後，再設定 Cloudflare 的 GitHub 連接。

1. 將修改後的 `wrangler.toml` 與 `package-lock.json` 提交到 GitHub。
2. 在 Cloudflare Workers 的 Builds／Git 設定中連接你的 GitHub 儲存庫與 `main` 分支。
3. 專案根目錄設為這份專案所在目錄；若檔案都在儲存庫根目錄，使用 `/` 或介面預設值。
4. Worker 專案名稱要與 `wrangler.toml` 的 `name` 相同（預設 `studyform`）。
5. 建置使用 Node 24；如需指定，於建置環境設 `NODE_VERSION=24`。
6. Build command 使用 `npm run build`；Deploy command 使用 `npm run deploy:github`。
7. 確認 Cloudflare 建置身分具有該 D1 的遷移及 Worker 部署權限。成功後，每次推送選定分支即可更新。

`deploy:github` 會先執行線上 D1 遷移再部署；請不要修改已套用的 SQL 遷移。正式資料庫與測試資料庫應分開。不要讓非正式分支共用正式資料庫做測試遷移。

官方說明：[Workers Builds](https://developers.cloudflare.com/workers/ci-cd/builds/)、[建置設定](https://developers.cloudflare.com/workers/ci-cd/builds/configuration/)。

## 8. 本機預覽與 GitHub Pages

直接雙擊根目錄 `index.html` 會開啟正式網站。完整可編輯介面在 `web/`，由建置腳本嵌入 Worker。

若要在本機測完整功能，完成 Wrangler 資源設定後執行：

```sh
npm run db:local
npm run dev
```

開啟 Wrangler 印出的本機網址。

GitHub Pages 使用入口頁開啟正式網站，網址會切換到正式網站；登入與同步皆在正式網站運行。不需處理跨網域 Cookie。若改用自己的 Worker，請更新 `hosted-site.json` 並重新執行建置。

## 9. 現有資料與交付邊界

這份 ZIP 是乾淨的原始碼與設定範本，沒有附上原網站的使用者帳號、密碼、資料庫、教材、API Key 或 Git 憑證。新部署使用新資料庫，第一次登入為空白。原網站純文字備份可在登入後匯入；原始檔案必須重新上傳。

尚未在你的 Cloudflare 帳戶實際部署；Gemini 推論使用每位使用者自己的 Key。Email 驗證、忘記密碼寄信及不同登入方式的帳號合併尚未實作。


## Email 登入版

根目錄 HTML 與 GitHub Pages 現在會前往已代管的正式網站。完整網站請使用代管網址，或依本文件部署完整後台。本機可執行 `npm run preview:local`，再開啟 `http://127.0.0.1:4180/`。
