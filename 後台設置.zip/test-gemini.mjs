import assert from 'node:assert/strict';
import {fetchExamResponse,geminiFailure} from './worker/index.mjs';
const makeResponse=(status,headers={})=>new Response(JSON.stringify({error:{status:'UNAVAILABLE',message:'upstream unavailable'}}),{status,headers});
async function scenario(sequence){let calls=0,clock=0;const delays=[];const result=await fetchExamResponse('https://example.invalid',{}, {fetcher:async()=>{const next=sequence[calls++];if(next instanceof Error)throw next;return next},sleep:async ms=>{delays.push(ms);clock+=ms},now:()=>clock,random:()=>0});return {result,calls,delays}}
let run=await scenario([makeResponse(503),makeResponse(500),makeResponse(200)]);
assert.equal(run.result.status,200);assert.equal(run.calls,3);assert.deepEqual(run.delays,[1000,2000]);
run=await scenario([makeResponse(429,{'retry-after':'3'}),makeResponse(200)]);assert.deepEqual(run.delays,[3000]);
run=await scenario([new Error('socket reset'),makeResponse(200)]);assert.equal(run.calls,2);
for(const status of [400,401,403,404]){run=await scenario([makeResponse(status)]);assert.equal(run.calls,1);assert.equal(run.result.status,status)}
run=await scenario([makeResponse(503),makeResponse(503),makeResponse(503)]);assert.equal(run.calls,3);assert.equal(run.result.status,503);
run=await scenario([makeResponse(429,{'retry-after':'3600'})]);assert.equal(run.calls,1);assert.equal(run.result.status,429);
let log='';const warn=console.warn;console.warn=value=>{log=value};
try{const key='test-secret-never-log';const error=geminiFailure(403,{error:{status:'PERMISSION_DENIED',message:'denied '+key}},key,'gemini-test');assert.equal(error.code,'GEMINI_HTTP_403');assert.ok(!log.includes(key));assert.ok(!error.message.includes(key));assert.match(error.message,/PERMISSION_DENIED/)}finally{console.warn=warn}
console.log('PASS Gemini transient retry, Retry-After, bounded attempts, permanent errors and credential redaction');
